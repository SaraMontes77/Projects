#ifndef TRUCK_H
#define TRUCK_H

#include "Vehicle.h"
#include <string>
using namespace std;

class Truck : public Vehicle {
public:
    Truck(string name, int durability, int fuel, int speed, int cargoCapacity, int price);

    void specialAbility() override;
    void handleEvent(string eventType, int eventEffect) override;
    void displayStats() const override;
};

#endif // TRUCK_H
