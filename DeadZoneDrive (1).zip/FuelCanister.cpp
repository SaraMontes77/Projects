#include "FuelCanister.h"
#include "Vehicle.h"  // Needed to call vehicle.increaseFuel

#include <iostream>
using namespace std;

FuelCanister::FuelCanister(string name, int amount)
    : Item(name), fuelAmount(amount) {}

void FuelCanister::use(Vehicle& vehicle) {
    cout << getName() << " used on " << vehicle.getName() << ". Adding " << fuelAmount << " fuel." << endl;
    vehicle.increaseFuel(fuelAmount);
}

