#include "Item.h"
#include "Vehicle.h"  // Include here where it's needed

#include <iostream>
using namespace std;

Item::Item(string name) : name(name) {}

Item::~Item() {}

string Item::getName() const {
    return name;
}

void Item::use(Vehicle& vehicle) {
    cout << "Used a generic item." << endl;
}
