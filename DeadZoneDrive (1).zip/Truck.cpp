#include "Truck.h"
#include <iostream>

using namespace std;

Truck::Truck(string _name, int _durability, int _fuel, int _speed, int _cargoCapacity, int _price)
    : Vehicle(_name, _durability, _fuel, _speed, _cargoCapacity, _price) {}

void Truck::specialAbility() {
    cout << R"(
        ______
       /|_||_\`.__
      (   _    _ _\
      =`-(_)--(_)-'
     )" << endl;
    cout << getName() << " attempts a powerful ram, potentially damaging obstacles!" << endl;
    cout << getName() << "'s strong frame might clear the way!" << endl;
    
    handleEvent("roughTerrain", rand() % 30 + 10); // will take 20% of the damage inside handleEvent
}

void Truck::handleEvent(string eventType, int eventEffect) {
    if (eventType == "roughTerrain") {
        cout << getName() << " handles the rough terrain with its sturdy build." << endl;
        cout << getName() << " takes minimal damage." << endl;
        Vehicle::handleEvent("damage", static_cast<int>(eventEffect * 0.2));
    } else {
        Vehicle::handleEvent(eventType, eventEffect);
    }
}

void Truck::displayStats() const {
    Vehicle::displayStats();
    cout << "Type: Truck" << endl;
}
