#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include "Vehicle.h"
#include "Truck.h"
#include "Motorcycle.h"
#include "Item.h"
#include "FuelCanister.h"
#include "RepairKit.h"
using namespace std;

// Constants
const int MAX_VEHICLES = 2;
const int MAX_INVENTORY = 5;
const int WINNING_CURRENCY = 3000;

void displayMainMenu(int currency){
    cout << "==============================" << endl;
    cout << "   VEHICLE ADVENTURE GAME" << endl;
    cout << "   Current Currency: $" << currency << endl;
    cout << "==============================" << endl;
    cout << "1. List Available Vehicles" << endl;
    cout << "2. Purchase Vehicle" << endl;
    cout << "3. Start a Run" << endl;
    cout << "4. View Inventory" << endl;
    cout << "5. Use Item" << endl;
    cout << "6. View Player Stats" << endl;
    cout << "7. Return To Main Menu" << endl;
    cout << "Enter your choice: ";
}

void listAvailableVehicles(Vehicle* available[], int count){
    cout << "Available Vehicles:" << endl;
    for (int i = 0; i < count; ++i) {
        cout << i + 1 << ". " << available[i]->getName() 
             << " ($" << available[i]->getPrice() << ")" << endl;
        available[i]->displayStats();
        cout << "----------------------------" << endl;
    }
}

Vehicle* purchaseVehicle(int& currency, Vehicle* available[], int& availableCount, Vehicle* owned[], int& ownedCount){
    listAvailableVehicles(available, availableCount);
    cout << "Enter the number of the vehicle you want to purchase: ";
    int choice;
    cin >> choice;
    if (choice < 1 || choice > availableCount) {
        cout << "Invalid choice." << endl;
        return nullptr;
    }

    Vehicle* selected = available[choice - 1];
    if (currency >= selected->getPrice()) {
        currency -= selected->getPrice();
        cout << "You purchased: " << selected->getName() << endl;
        owned[ownedCount++] = selected;

        // Shift available vehicles array
        for (int i = choice - 1; i < availableCount - 1; ++i) {
            available[i] = available[i + 1];
        }
        availableCount--;

        return selected;
    } else {
        cout << "Not enough currency!" << endl;
        return nullptr;
    }
}
void triggerRandomEvent(Vehicle* vehicle, Item* inventory[], int& inventoryCount){
    srand(static_cast<unsigned int>(time(0)));  // Seed once
    int eventType = rand() % 3; // 0 = damage, 1 = fuelLoss, 2 = item found


    if (eventType == 0) {
        // BANDIT AMBUSH
        cout << R"(
            \\\|///
           -( o o )-
      ---oOO--(_)---OOo---
        )" << endl;
        cout << "Random Event: Bandit Ambush!" << endl;

        cout << "Do you want to:\n";
        cout << "1. Evade (use speed)\n";
        cout << "2. Attack (risk durability)\n";
        cout << "Enter your choice: ";
        int choice;
        cin >> choice;

        int outcome = rand() % 100;

        if (choice == 1) {
            if (outcome < 60) {
                cout << "You successfully evaded the bandits!" << endl;
            } else {
                int damage = rand() % 20 + 10;
                cout << "Escape failed! Took " << damage << " damage." << endl;
                vehicle->handleEvent("damage", damage);
            }
        } else if (choice == 2) {
            if (outcome < 50) {
                cout << "You scared them off!" << endl;
            } else {
                int damage = rand() % 30 + 15;
                cout << "You fought but took " << damage << " damage." << endl;
                vehicle->handleEvent("damage", damage);
            }
        } else {
            cout << "Invalid action! You hesitated and took damage." << endl;
            int damage = rand() % 25 + 10;
            vehicle->handleEvent("damage", damage);
        }

    } else if (eventType == 1) {
        // FUEL LEAK
        cout << R"(
         _______
        |       |
        |  FUEL |
        | LEAK! |
        |_______|
          || ||
         (    )
        )" << endl;
        cout << "Random Event: Fuel Leak Detected!" << endl;
        cout << "Do you want to:\n";
        cout << "1. Pull over and try to patch it\n";
        cout << "2. Keep driving and ignore it\n";
        cout << "Enter your choice: ";
        int choice;
        cin >> choice;

        int outcome = rand() % 100;
        if (choice == 1) {
            if (outcome < 50) {
                cout << "You successfully patched the leak. No fuel lost!" << endl;
            } else {
                int fuelLoss = rand() % 15 + 5;
                cout << "The patch didn’t hold. You lost " << fuelLoss << " fuel." << endl;
                vehicle->handleEvent("fuelLoss", fuelLoss);
            }
        } else if (choice == 2) {
            int fuelLoss = rand() % 25 + 10;
            cout << "The leak worsened! You lost " << fuelLoss << " fuel." << endl;
            vehicle->handleEvent("fuelLoss", fuelLoss);
        } else {
            cout << "You hesitated and the tank kept leaking." << endl;
            vehicle->handleEvent("fuelLoss", rand() % 20 + 10);
        }

    } else {
        // ITEM CRATE FOUND
        cout << R"(
         _______
        /      /,
       / ITEM / /
      /______/ /
     (______( /
        )" << endl;
        cout << "You spot a crate near the road!" << endl;
        cout << "Do you want to:\n";
        cout << "1. Open it\n";
        cout << "2. Ignore it\n";
        cout << "Enter your choice: ";
        int choice;
        cin >> choice;

        int outcome = rand() % 100;

        if (choice == 1) {
            if (outcome < 70) {
                if (inventoryCount < MAX_INVENTORY) {
                    if (rand() % 2 == 0) {
                        inventory[inventoryCount++] = new FuelCanister("Fuel Canister", 25);
                        cout << R"(
                            ______
                           /      \
                          / FUEL   \
                         |          |
                          \        /
                           `------'
                        )" << endl;
                        cout << "Found a Fuel Canister!" << endl;
                    } else {
                        inventory[inventoryCount++] = new RepairKit("Repair Kit", 20);
                        cout << R"(
                            _________
                           /         \
                          |  REPAIR   |
                           \_________/
                        )" << endl;
                        cout << "Found a Repair Kit!" << endl;
                    }
                } else {
                    cout << "Inventory full! You couldn’t carry it." << endl;
                }
            } else {
                int damage = rand() % 15 + 5;
                cout << "It was a trap! The crate exploded. Took " << damage << " damage." << endl;
                vehicle->handleEvent("damage", damage);
            }
        } else if (choice == 2) {
            cout << "You drive past the crate safely." << endl;
        } else {
            cout << "You waited too long... the crate vanished." << endl;
        }
    }
}

void startRun(Vehicle* currentVehicle, int& currency, Item* inventory[], int& inventoryCount) {
    cout << "\nStarting a run with " << currentVehicle->getName() << "!" << endl;

    // Use the vehicle's special ability
    currentVehicle->specialAbility();

    // Simulate a random event
    triggerRandomEvent(currentVehicle, inventory, inventoryCount);

    // Check for fuel or durability failure
    if (currentVehicle->getDurability() <= 0) {
        cout << "\n💥 Your vehicle was destroyed in the wastes!" << endl;
        cout << R"(
       ____----___________
     /--/      ||  ||      \\
    |  | RIP   ||  ||   🚗  |
     \_\______||__||______/ 
        )" << endl;
        cout << "Game Over: You didn’t survive the run." << endl;
        exit(0);
    }

    if (currentVehicle->getFuel() <= 0) {
        cout << "\n⛽ You ran out of fuel and had to abandon your vehicle..." << endl;
        cout << R"(
         ______________
        |              |
        |  STRANDED... |
        |______________|
           (  .__.  )
            \______/ 
        )" << endl;
        cout << "Game Over: You were left to wander the wasteland alone." << endl;
        exit(0);
    }

    // Reward for completing the run
    int reward = rand() % 200 + 100;
    cout << "Run completed! You earned $" << reward << "!" << endl;
    currency += reward;

    // Check for win
    if (currency >= WINNING_CURRENCY) {
        cout << "\n🌟 Congratulations! 🌟" << endl;
        cout << "You've earned enough to escape the Dead Zone!" << endl;
        cout << R"(
             _________
            |         |
            | YOU WIN |
            |_________|
          ____||_____
         /    ||    \\
        (____________)
        )" << endl;
        cout << "You and your vehicle ride off into safety. The wasteland is behind you." << endl;
        exit(0);
    }
}
    


void displayInventory(Item* inventory[], int inventoryCount){
    if (inventoryCount == 0) {
        cout << "Inventory is empty." << endl;
        return;
    }
    cout << "Current Inventory:" << endl;
    for (int i = 0; i < inventoryCount; ++i) {
        cout << i + 1 << ". " << inventory[i]->getName() << endl;
    }
}

void showPlayerStats(int currency, Vehicle* currentVehicle) {
    cout << "\n====== PLAYER STATS ======" << endl;
    cout << "Currency: $" << currency << endl;

    if (currentVehicle) {
        cout << "Vehicle: " << currentVehicle->getName() << endl;
        cout << "Durability: " << currentVehicle->getDurability() << endl;
        cout << "Fuel: " << currentVehicle->getFuel() << endl;
        cout << "Speed: " << currentVehicle->getSpeed() << endl;
        cout << "Cargo Capacity: " << currentVehicle->getCargoCapacity() << endl;
        cout << "Price (original): $" << currentVehicle->getPrice() << endl;
    } else {
        cout << "Vehicle: None (You haven't bought one yet!)" << endl;
    }

    cout << "===========================\n" << endl;
}


void saveGame(int currency, Vehicle* currentVehicle, Item* inventory[], int inventoryCount) {
    ofstream fout("save.txt");
    if (!fout) {
        cout << "Error saving game!" << endl;
        return;
    }

    fout << "currency " << currency << endl;

    if (currentVehicle) {
        fout << "vehicle " 
             << (dynamic_cast<Truck*>(currentVehicle) ? "Truck" : "Motorcycle") << " "
             << currentVehicle->getName() << " "
             << currentVehicle->getDurability() << " "
             << currentVehicle->getFuel() << " "
             << currentVehicle->getSpeed() << " "
             << currentVehicle->getCargoCapacity() << " "
             << currentVehicle->getPrice() << endl;
    }

    for (int i = 0; i < inventoryCount; ++i) {
        if (dynamic_cast<FuelCanister*>(inventory[i])) {
            fout << "inventory FuelCanister " << inventory[i]->getName() << " 40" << endl;
        } else if (dynamic_cast<RepairKit*>(inventory[i])) {
            fout << "inventory RepairKit " << inventory[i]->getName() << " 25" << endl;
        }
    }

    fout.close();
    cout << "Game saved successfully." << endl;
}

void useItem(Vehicle* vehicle, Item* inventory[], int& inventoryCount) {
    if (inventoryCount == 0) {
        cout << "No items available!" << endl;
        return;
    }

    cout << "Inventory:" << endl;
    for (int i = 0; i < inventoryCount; ++i) {
        cout << i + 1 << ". " << inventory[i]->getName() << endl;
    }

    cout << "Select an item to use: ";
    int choice;
    cin >> choice;

    if (choice < 1 || choice > inventoryCount) {
        cout << "Invalid choice." << endl;
        return;
    }

    // Use the selected item
    inventory[choice - 1]->use(*vehicle);

    // Delete used item and shift inventory
    delete inventory[choice - 1];
    for (int i = choice - 1; i < inventoryCount - 1; ++i) {
        inventory[i] = inventory[i + 1];
    }
    inventoryCount--;
}


bool loadGame(int& currency, Vehicle*& currentVehicle, Item* inventory[], int& inventoryCount) {
    ifstream fin("save.txt");
    if (!fin) {
        throw runtime_error("No saved game found. save.txt could not be opened.");
    }


    string line;
    while (getline(fin, line)) {
        istringstream iss(line);
        string keyword;
        iss >> keyword;

        if (keyword == "currency") {
            iss >> currency;
        } else if (keyword == "vehicle") {
            string type, name;
            int durability, fuel, speed, cargo, price;
            iss >> type >> name >> durability >> fuel >> speed >> cargo >> price;
            if (type == "Truck") {
                currentVehicle = new Truck(name, durability, fuel, speed, cargo, price);
            } else if (type == "Motorcycle") {
                currentVehicle = new Motorcycle(name, durability, fuel, speed, cargo, price);
            }
        } else if (keyword == "inventory") {
            string type, name;
            int value;
            iss >> type >> name >> value;
            if (type == "FuelCanister") {
                inventory[inventoryCount++] = new FuelCanister(name, value);
            } else if (type == "RepairKit") {
                inventory[inventoryCount++] = new RepairKit(name, value);
            }
        }
    }

    fin.close();
    cout << "Game loaded successfully." << endl;
    return true;
}

int main() {
    try{
    Vehicle* availableVehicles[MAX_VEHICLES];
    int availableCount = 0;
    Vehicle* ownedVehicles[MAX_VEHICLES];
    int ownedCount = 0;
    Item* inventory[MAX_INVENTORY];
    int inventoryCount = 0;
    int currency = 1000;
    Vehicle* currentVehicle = nullptr;

    int mainChoice;
    bool running = true;

    while (running) {
        cout << "==============================" << endl;
        cout << "       Dead Zone Drive" << endl;
        cout << "==============================" << endl;
        cout << "1. Start New Game" << endl;
        cout << "2. Continue Game" << endl;
        cout << "3. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> mainChoice;

        switch (mainChoice) {
            case 1: { // Start New Game
                availableCount = 0;
                ownedCount = 0;
                inventoryCount = 0;
                currency = 1000;
                currentVehicle = nullptr;

                ifstream fin("vehicles.txt");
                if (!fin) {
                    throw std::runtime_error("Error: Could not open vehicles.txt. Make sure the file exists.");
                }

                cout << "Loading vehicles from vehicles.txt..." << endl;
                string type, name;
                int durability, fuel, speed, cargo, price;

                while (fin >> type >> name >> durability >> fuel >> speed >> cargo >> price) {
                    if (type == "Truck") {
                        availableVehicles[availableCount++] = new Truck(name, durability, fuel, speed, cargo, price);
                    } else if (type == "Motorcycle") {
                        availableVehicles[availableCount++] = new Motorcycle(name, durability, fuel, speed, cargo, price);
                    } else {
                        throw std::runtime_error("Error: Unknown vehicle type found in vehicles.txt.");
                    }
                }
                fin.close();


                // ENTER GAMEPLAY MENU RIGHT AWAY
                bool playing = true;
                while (playing) {
                    displayMainMenu(currency);
                    int choice;
                    cin >> choice;

                    switch (choice) {
                        case 1:
                            listAvailableVehicles(availableVehicles, availableCount);
                            break;
                        case 2: { // Buy Vehicle → Auto start run
                            currentVehicle = purchaseVehicle(currency, availableVehicles, availableCount, ownedVehicles, ownedCount);
                            if (currentVehicle != nullptr) {
                                startRun(currentVehicle, currency, inventory, inventoryCount);
                            }
                            break;
                        }
                        case 3:
                            if (currentVehicle != nullptr) {
                                startRun(currentVehicle, currency, inventory, inventoryCount);
                            } else {
                                cout << "You must purchase a vehicle first!" << endl;
                            }
                            break;
                        case 4:
                            displayInventory(inventory, inventoryCount);
                            break;
                        case 5:
                            if (currentVehicle != nullptr) {
                                useItem(currentVehicle, inventory, inventoryCount);
                            } else {
                                cout << "No vehicle selected!" << endl;
                            }
                            break;
                        case 6:
                            showPlayerStats(currency, currentVehicle);
                        break;
                        case 7:
                            cout << "Returning to Main Menu..." << endl;
                            playing = false;
                            break;
                        default:
                            cout << "Invalid choice. Try again." << endl;
                    }
                }
                
                break;
            }
            case 2: { // Continue Game
                if (!loadGame(currency, currentVehicle, inventory, inventoryCount)) {
                    cout << "Starting new game instead..." << endl;
                    mainChoice = 1; // fallback to new game
                    continue;
                }

                bool playing = true;
                while (playing) {
                    displayMainMenu(currency);
                    int choice;
                    cin >> choice;

                    switch (choice) {
                        case 1:
                            listAvailableVehicles(availableVehicles, availableCount);
                            break;
                        case 2: { // Buy Vehicle + immediately Start Run
                            currentVehicle = purchaseVehicle(currency, availableVehicles, availableCount, ownedVehicles, ownedCount);
                            if (currentVehicle != nullptr) {
                                startRun(currentVehicle, currency, inventory, inventoryCount);
                            }
                            break;
                        }
                        case 3:
                            if (currentVehicle != nullptr) {
                                startRun(currentVehicle, currency, inventory, inventoryCount);
                            } else {
                                cout << "You must purchase a vehicle first!" << endl;
                            }
                            break;
                        case 4:
                            displayInventory(inventory, inventoryCount);
                            break;
                        case 5:
                            if (currentVehicle != nullptr) {
                                useItem(currentVehicle, inventory, inventoryCount);
                            } else {
                                cout << "No vehicle selected!" << endl;
                            }
                            break;
                        case 6:
                            showPlayerStats(currency, currentVehicle);
                        break;
                        case 7:
                            cout << "Returning to Main Menu..." << endl;
                            playing = false;
                            break;
                        default:
                            cout << "Invalid choice. Try again." << endl;
                    }
                }
                break;
            }
            case 3:
                saveGame(currency, currentVehicle, inventory, inventoryCount);
                cout << "Exiting game..." << endl;
                running = false;
                break;

            default:
                cout << "Invalid choice. Try again." << endl;
        }
    }

    // Cleanup
    for (int i = 0; i < availableCount; ++i) delete availableVehicles[i];
    for (int i = 0; i < ownedCount; ++i) delete ownedVehicles[i];
    for (int i = 0; i < inventoryCount; ++i) delete inventory[i];
    }

    catch (const std::runtime_error& e) {
        cout << "Fatal Error: " << e.what() << endl;
        return 1; // exit with error
    }

    return 0;
}
