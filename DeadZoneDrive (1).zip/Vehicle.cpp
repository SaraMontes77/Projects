#include "Vehicle.h"
#include <iostream>

using namespace std;

Vehicle::Vehicle(string _name, int _durability, int _fuel, int _speed, int _cargoCapacity, int _price)
    : name(_name), durability(_durability), fuel(_fuel), speed(_speed), cargoCapacity(_cargoCapacity), price(_price) {}

Vehicle::~Vehicle() {}

string Vehicle::getName() const { return name; }
int Vehicle::getDurability() const { return durability; }
int Vehicle::getFuel() const { return fuel; }
int Vehicle::getSpeed() const { return speed; }
int Vehicle::getCargoCapacity() const { return cargoCapacity; }
int Vehicle::getPrice() const { return price; }

void Vehicle::specialAbility() {
    cout << getName() << " performs a generic vehicle action." << endl;
}

void Vehicle::handleEvent(string eventType, int eventEffect) {
    if (eventType == "damage") {
        durability -= eventEffect;
        cout << getName() << " took " << eventEffect << " damage. Current durability: " << durability << endl;
    } else if (eventType == "fuelLoss") {
        fuel -= eventEffect;
        cout << getName() << " lost " << eventEffect << " fuel. Current fuel: " << fuel << endl;
    } else {
        cout << getName() << " encountered an unknown event: " << eventType << " (Effect: " << eventEffect << ")" << endl;
    }
    if (durability <= 0) {
        cout << getName() << " has been destroyed!" << endl;
    }
    if (fuel <= 0) {
        cout << getName() << " has run out of fuel!" << endl;
    }
}

void Vehicle::displayStats() const {
    cout << "Name: " << name << endl;
    cout << "Durability: " << durability << endl;
    cout << "Fuel: " << fuel << endl;
    cout << "Speed: " << speed << endl;
    cout << "Cargo Capacity: " << cargoCapacity << endl;
}

void Vehicle::reduceDurability(int amount) {
    durability -= amount;
    if (durability < 0) durability = 0;
}

void Vehicle::reduceFuel(int amount) {
    fuel -= amount;
    if (fuel < 0) fuel = 0;
}

void Vehicle::increaseFuel(int amount) {
    fuel += amount;
}
