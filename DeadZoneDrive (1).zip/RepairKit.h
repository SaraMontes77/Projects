#ifndef REPAIRKIT_H
#define REPAIRKIT_H

#include "Item.h"
#include <string>
using namespace std;

class RepairKit : public Item {
private:
    int repairAmount;

public:
    RepairKit(string name = "Repair Kit", int amount = 25);

    void use(Vehicle& vehicle) override;
};

#endif // REPAIRKIT_H
