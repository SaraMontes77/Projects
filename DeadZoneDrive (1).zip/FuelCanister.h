#ifndef FUELCANISTER_H
#define FUELCANISTER_H

#include "Item.h"
#include <string>
using namespace std;

class FuelCanister : public Item {
private:
    int fuelAmount;

public:
    FuelCanister(string name = "Fuel Canister", int amount = 40);

    void use(Vehicle& vehicle) override;
};

#endif // FUELCANISTER_H
