#include "RepairKit.h"
#include "Vehicle.h"  // Needed to access vehicle methods

#include <iostream>
using namespace std;

RepairKit::RepairKit(string name, int amount)
    : Item(name), repairAmount(amount) {}

void RepairKit::use(Vehicle& vehicle) {
    cout << getName() << " used on " << vehicle.getName() << ". Restoring " << repairAmount << " durability." << endl;
    vehicle.reduceDurability(-repairAmount); // Use negative to increase durability
}
