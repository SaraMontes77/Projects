#include "Motorcycle.h"
#include <iostream>

using namespace std;

Motorcycle::Motorcycle(string _name, int _durability, int _fuel, int _speed, int _cargoCapacity, int _price)
    : Vehicle(_name, _durability, _fuel, _speed, _cargoCapacity, _price) {}

void Motorcycle::specialAbility() {
    cout << R"(
        __o
      _ \<_
     (_)/(_)
    )" << endl;
    cout << getName() << " performs a quick evasive maneuver!" << endl;
    cout << getName() << "'s agility might help in the next encounter!" << endl;

    handleEvent("banditAmbush", rand() % 30 + 10); // 75% damage reduction already handled inside handleEvent
}

void Motorcycle::handleEvent(string eventType, int eventEffect) {
    if (eventType == "banditAmbush") {
        cout << getName() << "'s speed allows it to partially evade the bandits!" << endl;
        Vehicle::handleEvent(eventType, static_cast<int>(eventEffect * 0.75)); 
    } else {
        Vehicle::handleEvent(eventType, eventEffect);
    }
}

void Motorcycle::displayStats() const {
    Vehicle::displayStats();
    cout << "Type: Motorcycle" << endl;
}
