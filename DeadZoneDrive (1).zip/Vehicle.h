#ifndef VEHICLE_H
#define VEHICLE_H
#include <iostream>
#include <string>
using namespace std;

class Vehicle
{
private:
    string name;
    int durability;
    int fuel;
    int speed;
    int cargoCapacity;
    int price;

public:
    Vehicle(string name, int durability, int fuel, int speed, int cargoCapacity, int price);
    virtual ~Vehicle();

    string getName() const;
    int getDurability() const;
    int getFuel() const;
    int getSpeed() const;
    int getCargoCapacity() const;
    int getPrice() const;

    virtual void specialAbility();
    virtual void handleEvent(string eventType, int eventEffect);
    virtual void displayStats() const;

    void reduceDurability(int amount);
    void reduceFuel(int amount);
    void increaseFuel(int amount);
};

#endif // VEHICLE_H

