#ifndef MOTORCYCLE_H
#define MOTORCYCLE_H

#include "Vehicle.h"
#include <string>
using namespace std;

class Motorcycle : public Vehicle {
public:
    Motorcycle(string name, int durability, int fuel, int speed, int cargoCapacity, int price);

    void specialAbility() override;
    void handleEvent(string eventType, int eventEffect) override;
    void displayStats() const override;
};

#endif // MOTORCYCLE_H
