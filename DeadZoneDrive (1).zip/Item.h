#ifndef ITEM_H
#define ITEM_H

#include <string>
using namespace std;

class Vehicle; // Forward declaration to avoid circular include

class Item {
private:
    string name;

public:
    Item(string name);
    virtual ~Item();

    string getName() const;
    virtual void use(Vehicle& vehicle);
};

#endif // ITEM_H
